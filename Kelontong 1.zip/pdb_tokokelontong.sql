-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2025 at 02:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pdb_tokokelontong`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id_log` int(11) NOT NULL,
  `waktu` datetime DEFAULT current_timestamp(),
  `user` varchar(100) DEFAULT NULL,
  `aksi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id_log`, `waktu`, `user`, `aksi`) VALUES
(1, '2025-12-02 09:07:16', 'Budi Admin', 'Login sukses sebagai Admin'),
(2, '2025-12-02 09:07:30', 'Budi Admin', 'Mengedit produk ID 8: Chitato Lite'),
(3, '2025-12-02 09:07:47', 'Siti Kasir', 'Login sukses sebagai Kasir'),
(4, '2025-12-02 09:08:06', 'Budi Admin', 'Login sukses sebagai Admin'),
(5, '2025-12-02 09:08:57', 'Andi Pembeli', 'Login sukses sebagai User'),
(6, '2025-12-02 09:09:37', 'Budi Admin', 'Login sukses sebagai Admin'),
(7, '2025-12-02 10:26:13', 'Andi Pembeli', 'Login sukses sebagai User'),
(8, '2025-12-02 10:39:33', 'Siti Kasir', 'Login sukses sebagai Kasir'),
(9, '2025-12-02 10:40:48', 'Budi Admin', 'Login sukses sebagai Admin'),
(10, '2025-12-02 10:42:27', 'Andi Pembeli', 'Login sukses sebagai User'),
(11, '2025-12-02 10:45:49', 'Budi Admin', 'Login sukses sebagai Admin'),
(12, '2025-12-02 10:53:38', 'Siti Kasir', 'Login sukses sebagai Kasir'),
(13, '2025-12-02 10:56:17', 'Budi Admin', 'Login sukses sebagai Admin'),
(14, '2025-12-02 11:21:32', 'Andi Pembeli', 'Login sukses sebagai User'),
(15, '2025-12-02 14:00:27', 'Budi Admin', 'Login sukses sebagai Admin'),
(16, '2025-12-02 14:00:41', 'Budi Admin', 'Mengedit produk ID 6: Teh Gelas'),
(17, '2025-12-02 14:00:54', 'Budi Admin', 'Mengedit produk ID 5: Bimoli Minyak Goreng'),
(18, '2025-12-02 14:01:43', 'Budi Admin', 'Mengedit produk ID 1: Kecap Bango'),
(19, '2025-12-02 14:01:55', 'Budi Admin', 'Mengedit produk ID 2: Beng Beng'),
(20, '2025-12-02 14:02:14', 'Budi Admin', 'Mengedit produk ID 3: Bluband'),
(21, '2025-12-02 22:10:55', 'Alfath', 'Login sukses sebagai User'),
(22, '2025-12-02 22:11:30', 'Budi Admin', 'Login sukses sebagai Admin'),
(23, '2025-12-02 23:04:03', 'Budi Admin', 'Login sukses sebagai Admin'),
(24, '2025-12-02 23:06:15', 'Budi Admin', 'Login sukses sebagai Admin');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_transaksi`, `id_produk`, `qty`, `subtotal`) VALUES
(1, 1, 1, 3, 12000),
(2, 2, 2, 2, 32000),
(3, 2, 1, 2, 8000),
(4, 3, 1, 1, 4000),
(5, 3, 3, 1, 6000),
(6, 3, 4, 1, 2000),
(7, 4, 6, 11, 11000),
(8, 5, 4, 20, 40000),
(9, 5, 1, 4, 16000),
(10, 6, 6, 1, 1000),
(11, 6, 5, 1, 12000),
(12, 7, 5, 1, 12000),
(13, 7, 4, 1, 2000),
(14, 7, 3, 1, 6000),
(15, 7, 2, 1, 16000),
(16, 7, 6, 1, 1000),
(17, 8, 5, 1, 12000),
(18, 8, 4, 1, 2000),
(19, 8, 3, 1, 6000),
(20, 8, 6, 1, 1000),
(21, 9, 3, 1, 6000),
(22, 9, 5, 1, 12000),
(23, 9, 6, 1, 1000),
(24, 9, 7, 1, 2000),
(25, 9, 1, 1, 4000),
(26, 10, 6, 1, 1000),
(27, 10, 1, 1, 4000),
(28, 10, 7, 1, 2000),
(29, 11, 7, 1, 2000),
(30, 11, 2, 1, 16000),
(31, 12, 3, 2, 12000),
(32, 13, 2, 1, 16000),
(33, 14, 3, 1, 6000),
(34, 14, 4, 1, 2000),
(35, 14, 7, 1, 2000),
(36, 15, 2, 3, 48000),
(37, 15, 8, 4, 10000),
(38, 16, 8, 1, 2500),
(39, 16, 6, 1, 1000),
(40, 16, 4, 1, 2000),
(41, 16, 7, 1, 2000),
(42, 16, 5, 1, 12000),
(43, 16, 1, 1, 4000),
(44, 17, 6, 1, 1000),
(45, 17, 7, 1, 2000),
(46, 17, 3, 1, 6000),
(47, 17, 2, 1, 16000),
(48, 18, 3, 1, 6000),
(49, 18, 8, 2, 5000),
(50, 19, 1, 3, 12000),
(51, 19, 2, 1, 16000),
(52, 19, 8, 1, 2500),
(53, 19, 7, 1, 2000),
(54, 19, 6, 1, 1000),
(55, 19, 5, 1, 12000),
(56, 20, 6, 3, 3000),
(57, 20, 1, 1, 4000),
(58, 20, 2, 1, 16000),
(59, 21, 4, 1, 2000),
(60, 21, 3, 1, 6000),
(61, 21, 5, 1, 12000),
(62, 21, 6, 1, 1000),
(63, 22, 6, 1, 1000),
(64, 22, 5, 1, 12000),
(65, 22, 4, 1, 2000),
(66, 22, 3, 1, 6000),
(67, 22, 8, 2, 5000),
(68, 23, 5, 1, 12000),
(69, 24, 3, 1, 6000),
(70, 25, 3, 1, 6000),
(71, 25, 2, 1, 16000),
(72, 26, 7, 1, 2000),
(73, 27, 4, 1, 2000),
(74, 28, 4, 1, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jenis_produk` varchar(50) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `stok` int(11) DEFAULT 0,
  `foto_produk` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `jenis_produk`, `harga_beli`, `harga_jual`, `stok`, `foto_produk`) VALUES
(1, 'Kecap Bango', 'Sembako', 3000, 4000, 20, '1423463144_WhatsApp_Image_2025-11-18_at_12.25.58__2_-removebg-preview.png'),
(2, 'Beng Beng', 'Makanan', 15000, 16000, 13, '871761720_WhatsApp_Image_2025-11-18_at_12.25.56__1_-removebg-preview.png'),
(3, 'Bluband', 'Sembako', 5000, 6000, 15, '1362937876_WhatsApp_Image_2025-11-18_at_12.25.58__1_-removebg-preview.png'),
(4, 'Pillow', 'Makanan', 1500, 2000, 11, '607895347_WhatsApp_Image_2025-11-18_at_12.25.56__2_-removebg-preview.png'),
(5, 'Bimoli Minyak Goreng', 'Sembako', 10000, 12000, 11, '1562223707_WhatsApp_Image_2025-11-18_at_12.25.57-removebg-preview.png'),
(6, 'Teh Gelas', 'Minuman', 950, 1000, 15, '157631347_Teh_gelas-removebg-preview.png'),
(7, 'Pencil Fable Castel', 'Alat Tulis', 1800, 2000, 12, '1531828080_6519210030211c03842293fe-faber-castell-graphite-sketch-pencil-set-removebg-preview.png'),
(8, 'Chitato Lite', 'Makanan', 2000, 2500, 1, '2093912458_WhatsApp_Image_2025-11-18_at_12.25.56-removebg-preview.png');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `total_transaksi` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tgl_transaksi`, `total_transaksi`, `id_user`) VALUES
(1, '2025-11-25 03:49:32', 12000, 5),
(2, '2025-11-25 03:53:46', 40000, 5),
(3, '2025-11-25 04:32:30', 12000, 5),
(4, '2025-11-25 04:39:15', 11000, 5),
(5, '2025-11-25 05:08:06', 56000, 5),
(6, '2025-11-25 11:32:13', 13000, 6),
(7, '2025-11-25 12:19:33', 37000, 6),
(8, '2025-11-26 04:07:33', 21000, 6),
(9, '2025-11-26 04:16:29', 25000, 6),
(10, '2025-11-26 04:19:21', 7000, 6),
(11, '2025-11-26 08:14:22', 18000, 6),
(12, '2025-11-26 08:20:35', 12000, 5),
(13, '2025-11-26 08:46:00', 16000, 7),
(14, '2025-11-26 08:46:43', 10000, 7),
(15, '2025-12-02 02:54:50', 58000, 5),
(16, '2025-12-02 03:00:22', 23500, 5),
(17, '2025-12-02 03:02:09', 25000, 6),
(18, '2025-12-02 03:07:54', 11000, 5),
(19, '2025-12-02 03:09:23', 45500, 6),
(20, '2025-12-02 04:26:58', 23000, 6),
(21, '2025-12-02 04:27:27', 21000, 6),
(22, '2025-12-02 04:31:31', 26000, 6),
(23, '2025-12-02 04:35:33', 12000, 6),
(24, '2025-12-02 04:44:57', 6000, 6),
(25, '2025-12-02 04:54:05', 22000, 5),
(26, '2025-12-02 04:55:38', 2000, 5),
(27, '2025-12-02 04:55:49', 2000, 5),
(28, '2025-12-02 04:56:01', 2000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `pass_user` varchar(255) NOT NULL,
  `jenis_user` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama_user`, `pass_user`, `jenis_user`) VALUES
(4, 'Budi Admin', '$2y$10$nhwm5DrX2dtK4dH07Y3Tauf7x2ppWE4VeD4ADzLe/YW33dTykSP2W', 'Admin'),
(5, 'Siti Kasir', '$2y$10$tx9qSItpl7lJd1ZtowiveuzcQKYpZrRqGyIdrGhvd9fOLkidSJU2a', 'Kasir'),
(6, 'Andi Pembeli', '$2y$10$F6kKg6sFZCoY2VFk19FxfODr5VpIkltWpaMej2vOY.MTC6td7kk3S', 'User'),
(7, 'Herlan', '$2y$10$9.rAD1wSbIegLvEG2QbTCevDKCdNH1BOqv/2/dzQq6f6tHmLpweIW', 'Kasir'),
(8, 'Alfath', '$2y$10$kFzHp8OyBSdwbG3JKHnx7.7Wxn2SD3G2.2IMDyJykmLCeDu5bbxmS', 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id_log`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
